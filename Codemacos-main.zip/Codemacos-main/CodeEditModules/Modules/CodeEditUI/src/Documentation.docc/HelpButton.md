# ``CodeEditUI/HelpButton``

## Usage

```swift
HelpButton {
    // an action to perform on click
}
```

## Preview

![Help Button](HelpButton_View.png)
