# ``TabBar``

Common types for `TabBar` items

## Overview

This module contains protocol for `TabBar` items to conform to and tab identifier type.
