import ShellClient

// swiftlint:disable:next identifier_name
var Current: World = .init()

// Inspired by: https://vimeo.com/291588126
struct World {
    var shellClient: ShellClient = .live()
}
